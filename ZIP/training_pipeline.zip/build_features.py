"""Layer 3: turns data/history/{windows,tasks,operators}.parquet + the raw traces
into the two training-ready feature tables, with column names/units matching
contracts/ml_features.md exactly. These two output files are NOT part of the
history.md contract deliverable — they are internal to the training repo, feeding
straight into train_models.py.

Run after simulate.py has produced data/history/.
"""

from __future__ import annotations

import argparse
import glob
import json
import statistics
from collections import defaultdict
from pathlib import Path

import pandas as pd

from idle_tracker import IdleTracker
from simulate import MACHINE_MODELS, MACHINES, SOIL_FILL_FACTOR

MIN_BASELINE_N = 3  # fewer than this many prior windows -> no z-score yet (cold start)


# --------------------------------------------------------------------------- #
# Anomaly features
# --------------------------------------------------------------------------- #

def _rescan_trace_for_elevated_rpm_and_env(trace_path: str, model_id: str) -> tuple[dict, dict]:
    """Re-walks one machine-day's trace file to compute two things windows.parquet
    doesn't carry: elevated_rpm_idle_min per hour (needs per-episode mean_rpm, which
    only idle_tracker.py's episodes have) and mean ambient temp_c per hour (from
    env.v1 lines, for hyd_oil_temp_over_ambient_c). Returns
    ({hour_key: elevated_rpm_min}, {hour_key: mean_ambient_c})."""
    low_idle_rpm = MACHINE_MODELS[model_id]["low_idle_rpm"]
    threshold_rpm = low_idle_rpm + 300

    idle = IdleTracker()
    elevated_by_hour: dict[str, float] = defaultdict(float)
    env_temps_by_hour: dict[str, list[float]] = defaultdict(list)
    current_hour_key = None

    with open(trace_path) as f:
        for line in f:
            env = json.loads(line)
            payload = env["payload"]
            if payload.get("schema") == "env.v1":
                hour_key = payload["ts"][:13]
                env_temps_by_hour[hour_key].append(payload["temp_c"])
                continue
            if payload.get("schema") != "raw.v1":
                continue

            hour_key = payload["ts"][:13]
            if current_hour_key is not None and hour_key != current_hour_key:
                from common.timeutil import parse_iso
                boundary_ts = parse_iso(payload["ts"]).replace(minute=0, second=0, microsecond=0)
                chunk = idle.split_at_boundary(boundary_ts)
                if chunk and chunk["mean_rpm"] and chunk["mean_rpm"] > threshold_rpm:
                    elevated_by_hour[current_hour_key] += chunk["duration_min"]
            current_hour_key = hour_key

            activity_hint = payload["sens"].get("activity_hint")
            machine_activity = ("OFF" if activity_hint == "OFF" else
                                 "IDLE" if activity_hint == "IDLE" else
                                 "WORKING" if activity_hint in
                                 ("DIGGING", "SWING_LOADED", "DUMPING", "SWING_EMPTY") else
                                 activity_hint)
            flat = {"ts": payload["ts"], "machine_activity": machine_activity,
                    "engine_rpm": payload["can"].get("190"), "seatbelt": payload["can"].get("1856")}
            finished = idle.add_sample(flat)
            if finished and finished["mean_rpm"] and finished["mean_rpm"] > threshold_rpm:
                elevated_by_hour[hour_key] += finished["duration_min"]

    env_mean_by_hour = {h: statistics.mean(v) for h, v in env_temps_by_hour.items()}
    return dict(elevated_by_hour), env_mean_by_hour


def _task_type_for_window(window_row, tasks_df) -> str | None:
    same_machine = tasks_df[tasks_df["machine_id"] == window_row["machine_id"]]
    overlap = same_machine[
        (same_machine["actual_start"] < window_row["window_end"])
        & (same_machine["actual_end"] > window_row["window_start"])
    ]
    return overlap.iloc[0]["task_type_id"] if len(overlap) else None


def _robust_baseline(values: list[float]) -> dict:
    med = statistics.median(values)
    mad = statistics.median([abs(v - med) for v in values]) or 0.0
    return {"median": med, "mad": mad, "n": len(values)}


def build_anomaly_features(history_dir: Path) -> pd.DataFrame:
    windows = pd.read_parquet(history_dir / "windows.parquet")
    tasks = pd.read_parquet(history_dir / "tasks.parquet")
    windows = windows.sort_values(["operator_id", "window_start"]).reset_index(drop=True)

    # --- rescan traces once per (machine_id, date) for the two features windows.parquet
    # can't provide on its own ---
    elevated_lookup: dict[str, float] = {}
    ambient_lookup: dict[str, float] = {}
    for trace_path in glob.glob(str(history_dir / "traces" / "*.jsonl")):
        machine_id = Path(trace_path).stem.rsplit("_", 1)[0]
        model_id = MACHINES[machine_id]["model_id"]
        elevated, ambient = _rescan_trace_for_elevated_rpm_and_env(trace_path, model_id)
        for hour_key, v in elevated.items():
            elevated_lookup[f"{machine_id}|{hour_key}"] = v
        for hour_key, v in ambient.items():
            ambient_lookup[f"{machine_id}|{hour_key}"] = v

    rows = []
    for _, w in windows.iterrows():
        hour_key = w["window_start"][:13]
        lookup_key = f"{w['machine_id']}|{hour_key}"
        productive_h = w["productive_min"] / 60 if w["productive_min"] else 0
        ambient_c = ambient_lookup.get(lookup_key)
        row = {
            "machine_id": w["machine_id"], "operator_id": w["operator_id"],
            "window_start": w["window_start"], "window_end": w["window_end"],
            "idle_ratio": w["idle_ratio"],
            "fuel_per_productive_h": w["fuel_per_productive_h"],
            "fuel_per_load": w["fuel_per_load"],
            "loads_per_productive_h": w["loads_per_productive_h"],
            "passes_per_h": (w["pass_count"] / productive_h) if productive_h > 0 else None,
            "seatbelt_unfastened_running_min": w["seatbelt_unfastened_running_min"],
            "long_idle_count": w["idle_long_count"],
            "elevated_rpm_idle_min": elevated_lookup.get(lookup_key, 0.0),
            "mean_engine_load_pct": w["mean_engine_load_pct"],
            "hyd_oil_temp_over_ambient_c": (
                (w["max_hyd_oil_temp_c"] - ambient_c)
                if w["max_hyd_oil_temp_c"] is not None and ambient_c is not None else None
            ),
            "alert_count": w["alert_count"],
            "task_type": _task_type_for_window(w, tasks),
            "power_mode": "SMART",  # constant in this generator — see simulate.py's known simplifications
            "sim_labels": list(w["sim_labels"]),
        }
        rows.append(row)

    feats = pd.DataFrame(rows)

    # --- z-scores vs each operator's own trailing history (expanding window, cold
    # start = no z yet; a live system would use a rolling 14-day window instead) ---
    numeric_metrics = [
        "idle_ratio", "fuel_per_productive_h", "fuel_per_load", "loads_per_productive_h",
        "passes_per_h", "seatbelt_unfastened_running_min", "long_idle_count",
        "elevated_rpm_idle_min", "mean_engine_load_pct", "hyd_oil_temp_over_ambient_c",
        "alert_count",
    ]
    for metric in numeric_metrics:
        z_col = f"z_{metric}"
        feats[z_col] = None
        for operator_id, group in feats.groupby("operator_id"):
            history: list[float] = []
            for idx in group.index:
                val = feats.at[idx, metric]
                if len(history) >= MIN_BASELINE_N:
                    base = _robust_baseline(history)
                    if base["mad"] > 0 and val is not None:
                        feats.at[idx, z_col] = 0.6745 * (val - base["median"]) / base["mad"]
                if val is not None:
                    history.append(val)

    return feats


# --------------------------------------------------------------------------- #
# ETA features
# --------------------------------------------------------------------------- #

def build_eta_features(history_dir: Path) -> pd.DataFrame:
    tasks = pd.read_parquet(history_dir / "tasks.parquet").sort_values("actual_start").reset_index(drop=True)
    operators = pd.read_parquet(history_dir / "operators.parquet").set_index("operator_id")

    rows = []
    op_rate_history: dict[tuple[str, str], list[float]] = defaultdict(list)  # (operator, task_type) -> [unit/h]
    cohort_rate_history: dict[tuple[str, str], list[float]] = defaultdict(list)  # (experience_level, task_type)
    task_type_rate_history: dict[str, list[float]] = defaultdict(list)

    for _, t in tasks.iterrows():
        machine_id = t["machine_id"]
        model_id = MACHINES[machine_id]["model_id"]
        soil_type = t["soil_type"]
        op = operators.loc[t["operator_id"]] if t["operator_id"] in operators.index else None
        exp_level = op["experience_level"] if op is not None else None

        rate_key_op = (t["operator_id"], t["task_type_id"])
        rate_key_cohort = (exp_level, t["task_type_id"])
        this_rate = t["actual_quantity"] / (t["duration_min"] / 60) if t["duration_min"] else None

        op_hist = op_rate_history[rate_key_op][-10:]
        if len(op_hist) >= 1:
            operator_rate_median, operator_rate_source = statistics.median(op_hist), "OPERATOR"
        elif cohort_rate_history[rate_key_cohort]:
            operator_rate_median = statistics.median(cohort_rate_history[rate_key_cohort])
            operator_rate_source = "COHORT"
        elif task_type_rate_history[t["task_type_id"]]:
            operator_rate_median = statistics.median(task_type_rate_history[t["task_type_id"]])
            operator_rate_source = "TASK_TYPE"
        else:
            operator_rate_median, operator_rate_source = None, None

        start_dt = pd.Timestamp(t["scheduled_start"])
        rows.append({
            "task_id": t["task_id"], "task_type": t["task_type_id"],
            "planned_quantity": t["planned_quantity"], "unit": t["unit"], "soil_type": soil_type,
            "fill_factor": SOIL_FILL_FACTOR.get(soil_type, 1.0),
            "material_density_t_m3": t["material_density_t_m3"],
            "haul_distance_m": t.get("haul_distance_m"),
            "truck_capacity_total_t": (
                (t["trucks_assigned"] or 0) * (t["truck_capacity_t"] or 0)
                if t["trucks_assigned"] is not None else None
            ),
            "machine_model": model_id, "attachment_capacity_m3": MACHINE_MODELS[model_id]["bucket_capacity_m3"],
            "power_mode": "SMART",
            "operator_rate_median": operator_rate_median, "operator_rate_source": operator_rate_source,
            "experience_years": op["experience_years"] if op is not None else None,
            "readiness_score": None,  # no readiness pipeline in this generator yet
            "rain_mm_h": 0.0, "temp_c": None, "heat_index_c": None,  # needs env join; left None, see README
            "start_hour": start_dt.hour, "hours_into_shift": (start_dt.hour - 6.25),
            "day_of_week": start_dt.dayofweek,
            "duration_min": t["duration_min"],  # TRAINING TARGET, not an inference-time feature
        })

        if this_rate:
            op_rate_history[rate_key_op].append(this_rate)
            cohort_rate_history[rate_key_cohort].append(this_rate)
            task_type_rate_history[t["task_type_id"]].append(this_rate)

    return pd.DataFrame(rows)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--history-dir", default="./data/history")
    args = ap.parse_args()
    history_dir = Path(args.history_dir)

    anomaly_feats = build_anomaly_features(history_dir)
    anomaly_feats.to_parquet(history_dir / "anomaly_features.parquet", index=False)
    print(f"anomaly_features.parquet: {len(anomaly_feats)} rows, {len(anomaly_feats.columns)} columns")

    eta_feats = build_eta_features(history_dir)
    eta_feats.to_parquet(history_dir / "eta_features.parquet", index=False)
    print(f"eta_features.parquet: {len(eta_feats)} rows, {len(eta_feats.columns)} columns")


if __name__ == "__main__":
    main()
