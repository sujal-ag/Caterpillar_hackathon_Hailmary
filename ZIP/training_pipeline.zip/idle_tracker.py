"""Idle episode segmentation (HLD §6.10 idle_episode table).

*** RECONCILE WARNING ***
backend/edge/ingest/idle.py does not exist in the runtime repo yet (confirmed by
searching the repo on 2026-09-24 — rollup.py references an `idle.IdleTracker` that
the backend hasn't built). This is P1's best-effort reimplementation of the same
semantics so the training pipeline is not blocked. Once the real idle.py exists,
diff this file against it and re-run generation if the bucket/duration logic differs
even slightly — train/serve skew on idle features quietly ruins the anomaly model.

Bucket thresholds (HLD §6.10): PAUSE < 3 min, SHORT 3-6, MEDIUM 6-9, LONG >= 9.
Sub-3-min pauses are truck swaps and are excluded from bucket counts (only added to
idling_time_min via rollup.add_idle_episode's own PAUSE handling).
"""

from __future__ import annotations

from common.timeutil import parse_iso


def _bucket(duration_min: float) -> str:
    if duration_min < 3:
        return "PAUSE"
    if duration_min < 6:
        return "SHORT"
    if duration_min < 9:
        return "MEDIUM"
    return "LONG"


class IdleTracker:
    """One instance per machine. Feed every flat sample in timestamp order.

    An idle episode is a contiguous run where `running` is True and `active` is False
    (mirrors rollup._running / rollup._active semantics exactly, so idle time here
    matches what RollupAccumulator itself would call idle for the same samples).
    """

    def __init__(self):
        self._episode_start = None
        self._rpm_sum = 0.0
        self._rpm_n = 0
        self._seatbelt_off_s = 0.0
        self._last_ts = None
        self._last_running_active = (None, None)

    def add_sample(self, sample: dict) -> dict | None:
        ts = parse_iso(sample["ts"])
        activity = sample.get("machine_activity")
        running = activity is not None and activity != "OFF"
        active = activity in ("WORKING", "TRAVELLING", "LIFTING") if activity else None
        rpm = sample.get("engine_rpm")
        seatbelt = sample.get("seatbelt")

        finished = None
        is_idle_now = bool(running and active is False)
        was_idle = bool(self._episode_start is not None)

        if is_idle_now and not was_idle:
            self._episode_start = ts
            self._rpm_sum = 0.0
            self._rpm_n = 0
            self._seatbelt_off_s = 0.0
        elif not is_idle_now and was_idle:
            finished = self._finish(ts)

        if self._episode_start is not None:
            if rpm is not None:
                self._rpm_sum += rpm
                self._rpm_n += 1
            if self._last_ts is not None and seatbelt == "UNFASTENED":
                dt = min((ts - self._last_ts).total_seconds(), 2.0)
                self._seatbelt_off_s += dt

        self._last_ts = ts
        return finished

    def close(self, at_ts) -> dict | None:
        if self._episode_start is None:
            return None
        return self._finish(at_ts if hasattr(at_ts, "astimezone") else parse_iso(at_ts))

    def split_at_boundary(self, boundary_ts) -> dict | None:
        """*** WORKS AROUND A ROLLUP.PY DESIGN GAP — SEE simulate.py HEADER ***

        rollup.add_idle_episode() credits an episode's ENTIRE duration to the hour
        it started in, and silently drops it if fed after that hour has already
        closed (`if start < self._hour.start: return`). Since an idle episode here
        only naturally finishes on an activity transition, any idle stretch that
        happens to straddle the top of the hour — a routine 30-45 min gap, not an
        edge case — would be dropped entirely if fed only at its true end.

        This method, called by the caller right when it detects an hour rollover
        while idle, closes out the current episode AT the boundary and immediately
        reopens a fresh one continuing from that same instant, so idle time is
        split cleanly into one episode per hour instead of being lost. Returns the
        just-closed chunk (or None if no episode was open).
        """
        if self._episode_start is None:
            return None
        chunk = self._finish(boundary_ts)
        self._episode_start = boundary_ts
        self._rpm_sum, self._rpm_n, self._seatbelt_off_s = 0.0, 0, 0.0
        return chunk

    def _finish(self, end_ts) -> dict:
        duration_min = (end_ts - self._episode_start).total_seconds() / 60
        episode = {
            "start_ts": self._episode_start.isoformat(),
            "end_ts": end_ts.isoformat(),
            "duration_min": round(duration_min, 3),
            "bucket": _bucket(duration_min),
            "mean_rpm": (self._rpm_sum / self._rpm_n) if self._rpm_n else None,
            "seatbelt_off_min": round(self._seatbelt_off_s / 60, 3),
        }
        self._episode_start = None
        return episode
