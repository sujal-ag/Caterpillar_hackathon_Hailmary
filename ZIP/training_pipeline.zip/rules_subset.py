"""Minimal rule evaluator for TRAINING-LABEL generation only.

*** SCOPE WARNING — read before trusting these numbers ***
contracts/rules.yaml defines 24 rules (R01-R24) with cooldowns, hysteresis,
escalation timers and per-subject suppression. Building a byte-faithful
reimplementation of that engine here would duplicate a large piece of backend
work and risks drifting from it silently. This module implements only the
handful of rules needed to produce non-null `alert_count`, `critical_count`
and `state_class_mode` for anomaly-model training (rollup.py currently leaves
these Phase-3 fields as None): R01, R03, R07, R08/R09, R10/R11, R12/R13,
R16/R17. It has NO cooldown/hysteresis logic — every sample where a predicate
is true counts as that rule being active for that second.

BEST FIX, once available: once the real rule engine exists in the backend
repo, replay these same synthetic traces through IT instead of this file, and
regenerate windows.parquet's alert fields from its actual output. That
eliminates any train/serve skew this approximation introduces. Until then,
treat alert_count/critical_count/state_class_mode in the generated dataset as
"directionally right, not authoritative."

Thresholds below are copied from data/seed/machine_models.yaml (HLD §6.0),
not re-derived, so at least the numbers are grounded even if the timing isn't.
"""

from __future__ import annotations

THRESHOLDS = {
    "CAT-320": {
        "pitch_caution_deg": 15,
        "pitch_critical_deg": 25,
        "roll_caution_deg": 10,
        "roll_critical_deg": 15,
        "roll_caution_lift_deg": 5,
        "proximity_critical_m": 3.8,
        "proximity_warning_m": 8.0,
    },
    "CAT-950GC": {
        "pitch_caution_deg": 12,
        "pitch_critical_deg": 20,
        "roll_caution_deg": 8,
        "roll_critical_deg": 12,
        "roll_caution_lift_deg": None,
        "proximity_critical_m": 5.0,
        "proximity_warning_m": 12.0,
    },
}


def _active(activity):
    return activity in ("WORKING", "TRAVELLING", "LIFTING")


def evaluate_sample(sample: dict, machine_model: str) -> list[tuple[str, str]]:
    """Returns [(rule_id, level), ...] of rules active on this single flat sample.

    `sample` extends the rollup-flat-sample keys with the extra fields these
    rules need: hyd_lockout, bucket_height_m, seat_occupied, door_open,
    pitch_deg, roll_deg, lift_mode, proximity_min_dist_m, dtc_action_class.
    """
    th = THRESHOLDS[machine_model]
    activity = sample.get("machine_activity")
    running = activity is not None and activity != "OFF"
    active = _active(activity) if activity else False
    seatbelt = sample.get("seatbelt")
    fired: list[tuple[str, str]] = []

    # R01 seatbelt_off_while_active
    if running and active and seatbelt == "UNFASTENED":
        fired.append(("R01", "CRITICAL"))

    # R03 exit_guard_unsafe (strong exit intent + any check failing)
    seat_occupied = sample.get("seat_occupied")
    door_open = sample.get("door_open")
    hyd_lockout = sample.get("hyd_lockout")
    bucket_height_m = sample.get("bucket_height_m")
    exit_intent = running and (seat_occupied is False or (seatbelt == "UNFASTENED" and door_open))
    grounded = bucket_height_m is not None and bucket_height_m <= 0.3
    if exit_intent and (running or hyd_lockout == "UNLOCKED" or not grounded):
        fired.append(("R03", "CRITICAL"))

    # R07 belt_bypass (belt fastened, seat empty > 5s handled by caller via a
    # rolling counter; here we approximate with the instantaneous condition)
    if running and seatbelt == "FASTENED" and seat_occupied is False:
        fired.append(("R07", "WARNING"))

    # R10 / R11 tilt
    pitch = abs(sample.get("pitch_deg") or 0)
    roll = abs(sample.get("roll_deg") or 0)
    lift_mode = sample.get("lift_mode", False)
    roll_caution = th["roll_caution_lift_deg"] if lift_mode and th["roll_caution_lift_deg"] else th["roll_caution_deg"]
    if pitch > th["pitch_critical_deg"] or roll > th["roll_critical_deg"]:
        fired.append(("R11", "CRITICAL"))
    elif pitch > th["pitch_caution_deg"] or roll > roll_caution:
        fired.append(("R10", "CAUTION"))

    # R12 / R13 proximity
    dist = sample.get("proximity_min_dist_m")
    if dist is not None and active:
        if dist < th["proximity_critical_m"]:
            fired.append(("R12", "CRITICAL"))
        elif dist < th["proximity_warning_m"]:
            fired.append(("R13", "WARNING"))

    # R16 / R17 DTC action class
    action_class = sample.get("dtc_action_class")
    if action_class == "STOP":
        fired.append(("R16", "CRITICAL"))
    elif action_class == "MONITOR":
        fired.append(("R17", "CAUTION"))

    return fired


class HourLabelAccumulator:
    """One per (machine, hour). Feed evaluate_sample()'s output for every 1 Hz
    sample; read off alert_count / critical_count / state_class_mode at hour end.

    alert_count / critical_count count RISING EDGES per rule (a rule going
    False->True), not seconds-active, matching the HLD's intent of "how many
    times did this fire" rather than "how long was it on".
    """

    LEVEL_RANK = {"UNSAFE": 2, "ATTENTION": 1, "PRODUCTIVE": 0}
    RULE_STATE_EFFECT = {
        "R01": "UNSAFE", "R03": "UNSAFE", "R07": "ATTENTION", "R08": "ATTENTION",
        "R09": "ATTENTION", "R10": "ATTENTION", "R11": "UNSAFE", "R12": "UNSAFE",
        "R13": "ATTENTION", "R16": "UNSAFE", "R17": "ATTENTION",
    }

    def __init__(self):
        self._was_active: set[str] = set()
        self.alert_count = 0
        self.critical_count = 0
        self._class_counts = {"PRODUCTIVE": 0, "ATTENTION": 0, "UNSAFE": 0}

    def add_sample(self, fired: list[tuple[str, str]]) -> None:
        now_active = {rule_id for rule_id, _level in fired}
        rising = now_active - self._was_active
        for rule_id in rising:
            self.alert_count += 1
            level = next(lvl for rid, lvl in fired if rid == rule_id)
            if level == "CRITICAL":
                self.critical_count += 1
        self._was_active = now_active

        worst = "PRODUCTIVE"
        for rule_id, _level in fired:
            effect = self.RULE_STATE_EFFECT.get(rule_id, "ATTENTION")
            if self.LEVEL_RANK[effect] > self.LEVEL_RANK[worst]:
                worst = effect
        self._class_counts[worst] += 1

    def finish(self) -> dict:
        mode = max(self._class_counts, key=self._class_counts.get)
        return {
            "alert_count": self.alert_count,
            "critical_count": self.critical_count,
            "state_class_mode": mode,
            "safety_alert_triggered": self.alert_count > 0,
        }
