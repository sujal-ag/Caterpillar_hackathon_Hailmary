"""Runs ON THE EDGE BOX. Polls a model registry (serve_models.py, or later the real
cloud-api's equivalent) for new model versions, downloads only what changed, verifies
sha256 before accepting anything, and atomically swaps it into the live models
directory — so a partially-downloaded or corrupted file can never be loaded by the
running backend (contracts/ml_runtime.md: "load() must fail loudly on a corrupt or
incompatible file. The backend then keeps the previous model.").

Typical use: a cron job / systemd timer on the edge box runs this every N minutes
while the site has connectivity; it's a no-op (fast exit) when nothing changed.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import tempfile
from pathlib import Path
from urllib.error import URLError
from urllib.request import urlopen


def _local_manifest(models_dir: Path) -> dict:
    path = models_dir / "manifest.json"
    return json.loads(path.read_text()) if path.exists() else {"models": {}}


def _sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def pull(registry_url: str, models_dir: Path, dry_run: bool = False) -> list[str]:
    models_dir.mkdir(parents=True, exist_ok=True)
    local = _local_manifest(models_dir)

    try:
        with urlopen(f"{registry_url}/models", timeout=10) as resp:
            remote_models: dict = json.loads(resp.read())
    except URLError as exc:
        print(f"registry unreachable ({exc}) — keeping current models, no change", file=sys.stderr)
        return []

    updated = []
    for name, remote_info in remote_models.items():
        local_info = local["models"].get(name)
        if local_info and local_info["sha256"] == remote_info["sha256"]:
            continue  # already up to date

        print(f"{name}: {local_info['version'] if local_info else '(none)'} "
              f"-> {remote_info['version']}")
        if dry_run:
            updated.append(name)
            continue

        # Download to a temp file first; only replace the live file after the
        # sha256 check passes, so a crash mid-download or a corrupted transfer
        # can never leave a bad file where the backend will try to load it.
        with tempfile.NamedTemporaryFile(dir=models_dir, delete=False) as tmp:
            tmp_path = Path(tmp.name)
            with urlopen(f"{registry_url}/models/{name}/latest", timeout=60) as resp:
                tmp.write(resp.read())

        actual_sha = _sha256(tmp_path)
        if actual_sha != remote_info["sha256"]:
            tmp_path.unlink(missing_ok=True)
            print(f"  SHA256 MISMATCH for {name} — expected {remote_info['sha256']}, "
                  f"got {actual_sha}. Discarding, keeping previous version.", file=sys.stderr)
            continue

        final_path = models_dir / name
        tmp_path.replace(final_path)  # atomic on the same filesystem
        local["models"][name] = remote_info
        updated.append(name)
        print(f"  OK -> {final_path}")

    if updated and not dry_run:
        (models_dir / "manifest.json").write_text(json.dumps(local, indent=2))
    return updated


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--registry-url", required=True, help="e.g. http://<jarvis-labs-host>:8080")
    ap.add_argument("--models-dir", default="./models")
    ap.add_argument("--dry-run", action="store_true", help="show what would change, download nothing")
    args = ap.parse_args()

    updated = pull(args.registry_url, Path(args.models_dir), dry_run=args.dry_run)
    if updated:
        print(f"\n{'Would update' if args.dry_run else 'Updated'}: {', '.join(updated)}")
        print("Restart/reload the edge backend's ml adapter so it picks up the new "
              "files (or implement hot-reload in backend/edge/ml/adapter.py, per plan.md §5.6).")
    else:
        print("Already up to date.")


if __name__ == "__main__":
    main()
