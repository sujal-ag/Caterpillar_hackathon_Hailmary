"""Synthetic data generator for P1's training pipeline.

Produces, per simulated shift:
  - a raw.v1-shaped 1 Hz JSONL trace (matches contracts/schemas/raw.v1.json)
  - a stream of dtc.v1 / env.v1 / proximity.v1 messages on the right cadence
  - a "flat sample" dict per second (the shape backend/edge/ingest/rollup.py's
    RollupAccumulator.add_sample() actually consumes — see NOTE below)
  - zero or more completed task.v1-shaped records

NOTE ON THE FLAT-SAMPLE FORMAT: rollup.py does not consume raw.v1 (nested,
SPN-keyed) directly. Ingest normalises raw.v1 -> telemetry.v1 (nested,
contracts/schemas/telemetry.v1.json) and then flattens further before feeding
rollup.py — that flattening step isn't in the repo yet either. This module
generates ONE canonical per-second state and serialises it two ways: the
wire-format raw.v1 dict (for traces/*.jsonl) and the flat dict rollup.py
expects (for windows.parquet), so both outputs are guaranteed to agree with
each other by construction rather than by two independent implementations.

KNOWN SIMPLIFICATIONS (read before treating this as final training data):
  - Fuel/temperature dynamics are exponential-smoothing toward a state-
    dependent target, not the real thermal/engine model. Good enough for
    schema-correct, directionally-realistic data; not validated against a
    real CAT 320/950GC duty cycle.
  - Idle-episode and anomaly injection rates approximate HLD §6.14's table;
    they are applied per-hour/per-shift with fixed probabilities, not the
    full persona x weather x task interaction model the HLD describes.
  - Weather is a single deterministic daily sinusoid per site, not sourced
    from a real forecast API or varied day-to-day beyond a rain flag.
  - Task soil/quantity sampling is uniform-random within HLD ranges, not
    tied to a real site plan or zone schedule.
Tune these once the pipeline is proven end-to-end; the priority here was
schema/contract compatibility, not physical fidelity.
"""

from __future__ import annotations

import argparse
import json
import math
import random
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from pathlib import Path

from common.ids import uuid7
from common.timeutil import SITE_TZ, parse_iso
from idle_tracker import IdleTracker
from rollup import RollupAccumulator
from rules_subset import HourLabelAccumulator, evaluate_sample

SITE_ID = "SITE-PUN-01"

MACHINES = {
    "EXC001": {"model_id": "CAT-320", "operator_pref": "OP1001"},
    "EXC002": {"model_id": "CAT-320", "operator_pref": "OP1002"},
    "WL001": {"model_id": "CAT-950GC", "operator_pref": "OP1002"},
}

MACHINE_MODELS = {
    "CAT-320": {
        "family": "EXCAVATOR",
        "low_idle_rpm": 1000, "rated_rpm": 2200, "high_idle_rpm": 2200,
        "idle_fuel_lph": 2.0, "fuel_lph_light": 8.5, "fuel_lph_med": 12.5, "fuel_lph_heavy": 17.0,
        "nominal_cycle_s": 18, "bucket_capacity_m3": 1.19,
        "passes_per_load": 6,
        "coolant_target_idle": 82, "coolant_target_work": 90,
        "hyd_target_idle": 45, "hyd_target_work": 65,
        "tail_swing_radius_m": 2.83,
        "attachment_id": "ATT-GP-119",
    },
    "CAT-950GC": {
        "family": "WHEEL_LOADER",
        "low_idle_rpm": 800, "rated_rpm": 1700, "high_idle_rpm": 2200,
        "idle_fuel_lph": 3.0, "fuel_lph_light": 13.5, "fuel_lph_med": 17.5, "fuel_lph_heavy": 22.5,
        "nominal_cycle_s": 37, "bucket_capacity_m3": 3.65,
        "passes_per_load": 1,
        "coolant_target_idle": 82, "coolant_target_work": 90,
        "hyd_target_idle": 45, "hyd_target_work": 65,
        "tail_swing_radius_m": None,
        "attachment_id": "ATT-GP-365",
    },
}

# HLD §6.14 persona table.
PERSONAS = {
    "VETERAN": {"cycle_mult": 0.88, "fill_mult": 1.05, "idle_prop": "low",
                "belt_compliance": 0.98, "p_unsafe_exit": 0.02, "fuel_mult": 0.92},
    "AVERAGE": {"cycle_mult": 1.00, "fill_mult": 1.00, "idle_prop": "medium",
                "belt_compliance": 0.92, "p_unsafe_exit": 0.08, "fuel_mult": 1.00},
    "NOVICE": {"cycle_mult": 1.25, "fill_mult": 0.90, "idle_prop": "high",
               "belt_compliance": 0.90, "p_unsafe_exit": 0.15, "fuel_mult": 1.15},
    "CARELESS": {"cycle_mult": 0.95, "fill_mult": 1.00, "idle_prop": "high",
                 "belt_compliance": 0.60, "p_unsafe_exit": 0.40, "fuel_mult": 1.20},
}

OPERATORS = [
    {"operator_id": "OP1001", "name": "Demo Operator", "experience_years": 6,
     "experience_level": "VETERAN", "persona": "AVERAGE", "languages": ["en"]},
    {"operator_id": "OP1002", "name": "Operator B", "experience_years": 2,
     "experience_level": "INTERMEDIATE", "persona": "NOVICE", "languages": ["en", "hi"]},
]

TASK_TYPES = {
    "TRUCK_LOAD": {"unit": "M3", "machines": ["CAT-320", "CAT-950GC"], "rate": (140, 280)},
    "BULK_EXC": {"unit": "M3", "machines": ["CAT-320"], "rate": (120, 180)},
    "TRENCH": {"unit": "M3", "machines": ["CAT-320"], "rate": (40, 90)},
    "BACKFILL": {"unit": "M3", "machines": ["CAT-320", "CAT-950GC"], "rate": (100, 180)},
    "GRADE": {"unit": "M2", "machines": ["CAT-320"], "rate": (150, 400)},
    "LOAD_CARRY": {"unit": "M3", "machines": ["CAT-950GC"], "rate": (120, 220)},
}

SOIL_TYPES = ["LOAM", "SAND_GRAVEL", "CLAY_DRY", "CLAY_WET", "ROCK_BLASTED"]
SOIL_FILL_FACTOR = {"LOAM": 1.05, "SAND_GRAVEL": 1.02, "CLAY_DRY": 0.85, "CLAY_WET": 0.95, "ROCK_BLASTED": 0.68}
SOIL_DENSITY = {"LOAM": 1.6, "SAND_GRAVEL": 1.8, "CLAY_DRY": 1.9, "CLAY_WET": 1.7, "ROCK_BLASTED": 1.5}

DIAG_CODES = [
    {"spn": 1638, "fmi": 16, "action_class": "MONITOR"},  # hyd oil temp high
    {"spn": 110, "fmi": 0, "action_class": "STOP"},        # coolant critical
    {"spn": 110, "fmi": 16, "action_class": "MONITOR"},    # coolant trending high
    {"spn": 100, "fmi": 1, "action_class": "STOP"},        # oil pressure low
]

# Per-hour / per-shift injection probabilities, approximating HLD §6.14.
HOURLY_ANOMALY_RATES = {
    "HIGH_IDLE_RPM": 0.03,
    "FUEL_INEFFICIENCY": 0.02,
    "TILT_EXCURSION": 0.005,
    "PROXIMITY_INTRUSION": 0.02,
    "LONG_IDLE_UNBELTED": 0.03,
}
SHIFT_ANOMALY_RATES = {"BELT_BYPASS": 0.01, "OVERHEAT_TREND": 0.01, "DTC": 1 / 35}  # DTC ~1/machine-week
# NOTE: BELT_BYPASS and OVERHEAT_TREND are defined here per HLD §6.14 but NOT YET
# INJECTED by simulate_period() below — only DTC (as a discrete one-off event) and
# the flagship UNSAFE_EXIT (via simulate_exit(), added at shift end) are implemented
# beyond the original 5 HOURLY_ANOMALY_RATES types. Treat this as a known gap: the
# generated dataset under-represents BELT_BYPASS and OVERHEAT_TREND until someone
# extends simulate_period() to inject them the same way HIGH_IDLE_RPM etc. work.


def _lag(current: float, target: float, alpha: float = 0.08) -> float:
    return current + (target - current) * alpha


@dataclass
class MachineState:
    machine_id: str
    model_id: str
    engine_hours: float
    fuel_used_total_l: float = 0.0
    pass_count: int = 0
    load_count: int = 0
    coolant_c: float = 30.0
    hyd_oil_c: float = 30.0
    fuel_rate: float = 0.0
    x_m: float = 100.0
    y_m: float = 80.0
    heading_deg: float = 0.0


def make_operator_pool(n_synthetic: int, rng: random.Random) -> list[dict]:
    pool = list(OPERATORS)
    persona_names = list(PERSONAS.keys())
    for i in range(n_synthetic):
        pid = f"OP20{i:02d}"
        persona = rng.choices(persona_names, weights=[20, 45, 20, 5])[0]
        pool.append({
            "operator_id": pid,
            "name": f"Synthetic Operator {i+1}",
            "experience_years": round(rng.uniform(0.5, 15), 1),
            "experience_level": rng.choice(["NOVICE", "INTERMEDIATE", "VETERAN"]),
            "persona": persona,
            "languages": ["en"],
        })
    return pool


def weather_at(dt_local: datetime) -> dict:
    """Simple daily sinusoid: cool + humid early morning, hot + dry afternoon."""
    hour_frac = dt_local.hour + dt_local.minute / 60
    temp_c = 24 + 12 * math.sin(math.pi * (hour_frac - 6) / 14) if 6 <= hour_frac <= 20 else 22
    temp_c = max(20, temp_c)
    rh_pct = max(35, 95 - 3.2 * max(0, hour_frac - 6))
    is_dew = hour_frac < 9 and rh_pct >= 88
    return {
        "temp_c": round(temp_c, 1),
        "rh_pct": round(rh_pct, 1),
        "dew_point_spread_c": round(max(0.2, 3.0 - rh_pct / 40), 2),
        "is_wet": is_dew,
        "rain_flag": False,
    }


def raw_v1(ts_iso: str, machine_id: str, can: dict, sens: dict, sim_label: str | None) -> dict:
    return {
        "schema": "raw.v1", "ts": ts_iso, "site_id": SITE_ID, "machine_id": machine_id,
        "can": can, "sens": sens, "sim_label": sim_label,
    }


def wrap(topic: str, payload: dict, retain: bool = False) -> dict:
    """*** REQUIRED WIRE ENVELOPE ***
    contracts/history.md says trace files are "Lines in replay.py format". Per
    backend/tools/replay.py itself, that format is {"topic", "payload", "retain"?}
    — NOT the bare raw.v1/dtc.v1/etc. payload. An earlier version of this generator
    wrote bare payloads; that would fail to replay through tools/replay.py or
    tools/record.py's line format. Every line written to a trace file must go
    through this wrapper."""
    return {"topic": topic, "payload": payload, "retain": retain}


def topic_raw(machine_id): return f"cat/{SITE_ID}/{machine_id}/raw"
def topic_dtc(machine_id): return f"cat/{SITE_ID}/{machine_id}/dtc"
def topic_sim_proximity(machine_id): return f"cat/{SITE_ID}/{machine_id}/sim/proximity"
def topic_env(): return f"cat/{SITE_ID}/env"


def flat_sample(ts_iso: str, operator_id: str | None, activity: str, ms: MachineState,
                 seatbelt: str, extras: dict) -> dict:
    """The shape rollup.py + idle_tracker.py + rules_subset.py consume."""
    base = {
        "ts": ts_iso, "operator_id": operator_id, "machine_activity": activity,
        "fuel_used_total_l": round(ms.fuel_used_total_l, 5),
        "load_count": ms.load_count, "pass_count": ms.pass_count,
        "engine_load_pct": extras.get("engine_load_pct"),
        "seatbelt": seatbelt, "hyd_oil_temp_c": round(ms.hyd_oil_c, 2),
        "engine_hours": round(ms.engine_hours, 4), "payload_kg": extras.get("payload_kg", 0),
        "engine_rpm": extras.get("engine_rpm"),
    }
    base.update(extras.get("passthrough", {}))
    return base


def simulate_exit(machine_id: str, model_id: str, operator: dict, rng: random.Random,
                   ms: MachineState, t0: datetime, unsafe: bool, wet: bool):
    """End-of-shift dismount sequence, matching contracts/sim_control.md's unsafe_exit /
    safe_exit scenario specs exactly (timing and signal order), not the generic
    simulate_period() physics — this is a short, scripted event sequence.

    unsafe_exit: belt off -> seat vacated (+2s) -> door open with bucket raised (~2.1m)
    and hydraulics unlocked -> correction (bucket down, hyd locked, engine off) ~14s
    after the seat is vacated (~16s from sequence start).
    safe_exit: bucket grounded, hydraulics locked, engine off, THEN belt off -> seat
    vacated (sim_label stays null throughout — SAFE_EXIT isn't in the sim_label enum).

    Yields (raw_msg, flat, None, None) per second; the caller writes/feeds these
    exactly like simulate_period()'s output.
    """
    model = MACHINE_MODELS[model_id]
    total_s = 22
    seat_vacate_s = 2
    correction_s = 14  # after seat vacate, per sim_control.md

    for s in range(total_s):
        ts = t0 + timedelta(seconds=s)
        ts_iso = ts.isoformat(timespec="milliseconds")

        if unsafe:
            seatbelt = "UNFASTENED"
            seat_occupied = s < seat_vacate_s
            door_open = s >= seat_vacate_s
            corrected = s >= seat_vacate_s + correction_s
            hyd_lockout = "LOCKED" if corrected else "UNLOCKED"
            bucket_height_m = 0.2 if corrected else 2.1
            engine_state = "OFF" if corrected and s >= total_s - 3 else "RUNNING"
            sim_label = "UNSAFE_EXIT"
        else:
            engine_off_s = 3
            grounded_first = s >= 0
            hyd_lockout = "LOCKED"
            bucket_height_m = 0.2
            engine_state = "OFF" if s >= engine_off_s else "RUNNING"
            seatbelt = "UNFASTENED" if s >= engine_off_s + 1 else "FASTENED"
            seat_occupied = s < engine_off_s + 2
            door_open = s >= engine_off_s + 2
            sim_label = None

        running = engine_state == "RUNNING"
        ms.engine_hours += (1 / 3600) if running else 0
        engine_rpm = model["low_idle_rpm"] if running else 0
        activity = "IDLE" if running else "OFF"

        can = {
            "190": engine_rpm, "92": 5 if running else 0, "183": round(ms.fuel_rate * 0.3, 2) if running else 0.0,
            "250": round(ms.fuel_used_total_l, 4), "96": 60.0, "1761": 70.0,
            "247": round(ms.engine_hours, 4), "110": round(ms.coolant_c, 1), "100": 290 if running else 0,
            "1638": round(ms.hyd_oil_c, 1), "168": 27.0, "84": 0.0,
            "1856": seatbelt, "70": "ON", "523": 0,
        }
        sens = {
            "engine_state": engine_state, "hyd_pump_press_kpa": 3100 if running else 0,
            "swing_rate_deg_s": 0.0, "boom_angle_deg": 20.0, "stick_angle_deg": -50.0,
            "bucket_angle_deg": -10.0, "bucket_height_m": bucket_height_m, "boom_tip_height_m": 3.0,
            "payload_kg": 0, "pass_count": ms.pass_count, "load_count": ms.load_count,
            "idle_hours_total": 0.0, "pitch_deg": 1.0, "roll_deg": 1.0,
            "x_m": round(ms.x_m, 1), "y_m": round(ms.y_m, 1), "heading_deg": round(ms.heading_deg, 1),
            "seat_occupied": seat_occupied, "door_open": door_open, "hyd_lockout": hyd_lockout,
            "joystick_active": False, "lift_mode": False, "power_mode": "SMART",
            "attachment_id": model["attachment_id"], "coupler_lock": "LOCKED",
            "cab_temp_c": 28.0, "cab_ac_on": running, "articulation_deg": None,
            "activity_hint": "OFF" if not running else "IDLE",
        }
        raw_msg = raw_v1(ts_iso, machine_id, can, sens, sim_label)
        flat = flat_sample(ts_iso, operator["operator_id"], activity, ms, seatbelt, {
            "engine_load_pct": can["92"], "payload_kg": 0, "engine_rpm": engine_rpm,
            "passthrough": {
                "hyd_lockout": hyd_lockout, "bucket_height_m": bucket_height_m,
                "seat_occupied": seat_occupied, "door_open": door_open,
                "pitch_deg": 1.0, "roll_deg": 1.0, "lift_mode": False,
                "proximity_min_dist_m": None, "dtc_action_class": None,
            },
        })
        yield raw_msg, flat, None, None


def simulate_period(mode: str, machine_id: str, model_id: str, operator: dict, rng: random.Random,
                     ms: MachineState, t0: datetime, duration_min: float, anomaly_state: dict,
                     soil_type: str | None = None):
    """Simulates one contiguous period of either mode="WORK" or mode="IDLE".

    `anomaly_state` is a mutable dict {"active": str|None, "end_s": int, "global_s": int}
    shared and threaded across consecutive calls for the same machine-day, so an
    anomaly injected near the end of one period can continue into the next, and the
    once-per-simulated-hour injection check uses a running second-counter rather than
    restarting at 0 every period (which would bias injection toward period starts).

    Yields (raw_msg, flat_sample, proximity_msg_or_None). Mutates `ms` in place
    (fuel/engine hours/pass/load counters/quantity produced).
    """
    model = MACHINE_MODELS[model_id]
    persona = PERSONAS[operator["persona"]]
    fill_factor = SOIL_FILL_FACTOR.get(soil_type, 1.0) * persona["fill_mult"] if soil_type else 1.0
    cycle_s = model["nominal_cycle_s"] * persona["cycle_mult"]

    seatbelt = "FASTENED" if rng.random() < persona["belt_compliance"] else "UNFASTENED"
    hyd_lockout = "LOCKED" if mode == "IDLE" else "UNLOCKED"
    seat_occupied = True
    door_open = False
    phase_idx = 0
    phases = ["DIGGING", "SWING_LOADED", "DUMPING", "SWING_EMPTY"] if model["family"] == "EXCAVATOR" else ["DIGGING", "TRAVELLING"]
    phase_elapsed = 0.0
    seconds_per_phase = cycle_s / len(phases)
    per_pass_qty = model["bucket_capacity_m3"] * fill_factor

    n_seconds = int(round(duration_min * 60))
    for s in range(n_seconds):
        ts = t0 + timedelta(seconds=s)
        ts_iso = ts.isoformat(timespec="milliseconds")
        anomaly_state["global_s"] += 1
        gs = anomaly_state["global_s"]

        # --- once-per-simulated-hour anomaly injection, using a running clock so it
        # isn't biased toward the start of each period ---
        if gs % 3600 == 0 and anomaly_state["active"] is None:
            for label, p in HOURLY_ANOMALY_RATES.items():
                if rng.random() < p:
                    anomaly_state["active"], anomaly_state["end_s"] = label, gs + rng.randint(180, 900)
                    break
        if anomaly_state["active"] and gs >= anomaly_state["end_s"]:
            anomaly_state["active"] = None
        active_anomaly = anomaly_state["active"]

        # Base activity from mode; an anomaly may override it below. Counter
        # advancement (pass/load) is gated on the FINAL activity value, so a
        # mid-task anomaly that forces IDLE never corrupts the pass/load tally.
        activity = "WORKING" if mode == "WORK" else "IDLE"
        target_fuel = (model["fuel_lph_med"] * persona["fuel_mult"] if mode == "WORK"
                       else model["idle_fuel_lph"])
        target_rpm = model["rated_rpm"] if mode == "WORK" else model["low_idle_rpm"]
        engine_load_pct = (55 + rng.uniform(-10, 10)) if mode == "WORK" else (8 + rng.uniform(-3, 3))
        pitch_deg, roll_deg = rng.uniform(-2, 2), rng.uniform(-2, 2)
        proximity_dist = None
        dtc_action_class = None

        if active_anomaly == "HIGH_IDLE_RPM":
            activity = "IDLE"
            target_rpm = model["low_idle_rpm"] + 350
            target_fuel = model["idle_fuel_lph"] * 1.8
        elif active_anomaly == "FUEL_INEFFICIENCY" and mode == "WORK":
            target_fuel *= 1.5
        elif active_anomaly == "TILT_EXCURSION" and mode == "WORK":
            roll_deg = rng.uniform(11, 17) * rng.choice([-1, 1])
        elif active_anomaly == "PROXIMITY_INTRUSION" and mode == "WORK":
            proximity_dist = round(rng.uniform(2, 6), 1)
        elif active_anomaly == "LONG_IDLE_UNBELTED":
            activity = "IDLE"
            seatbelt = "UNFASTENED"
            target_fuel = model["idle_fuel_lph"]

        # DTC: a discrete one-off event (not a sustained state override like the
        # anomalies above), checked on the same running hourly clock.
        dtc_fire = None
        if gs % 3600 == 0 and rng.random() < SHIFT_ANOMALY_RATES["DTC"] * (3600 / 3600):
            dtc_fire = rng.choice(DIAG_CODES)
            dtc_action_class = dtc_fire["action_class"]

        if activity == "WORKING":
            phase_elapsed += 1
            if phase_elapsed >= seconds_per_phase:
                phase_elapsed = 0.0
                phase_idx = (phase_idx + 1) % len(phases)
                if phases[phase_idx] == "DIGGING":  # cycle completed
                    ms.pass_count += 1
                    if ms.pass_count % model["passes_per_load"] == 0:
                        ms.load_count += 1
            activity_hint = phases[phase_idx]
        else:
            activity_hint = "IDLE"

        payload_kg = 0
        ms.fuel_rate = _lag(ms.fuel_rate, target_fuel)
        ms.fuel_used_total_l += ms.fuel_rate / 3600
        ms.engine_hours += 1 / 3600
        coolant_target = model["coolant_target_work"] if activity == "WORKING" else model["coolant_target_idle"]
        hyd_target = model["hyd_target_work"] if activity == "WORKING" else model["hyd_target_idle"]
        ms.coolant_c = _lag(ms.coolant_c, coolant_target, alpha=0.02)
        ms.hyd_oil_c = _lag(ms.hyd_oil_c, hyd_target, alpha=0.015)

        engine_rpm = target_rpm + rng.uniform(-15, 15)

        can = {
            "190": round(engine_rpm), "92": round(engine_load_pct),
            "183": round(ms.fuel_rate, 2), "250": round(ms.fuel_used_total_l, 4),
            "96": 60.0, "1761": 70.0, "247": round(ms.engine_hours, 4),
            "110": round(ms.coolant_c, 1), "100": 290, "1638": round(ms.hyd_oil_c, 1),
            "168": 27.0, "84": 0.0 if activity != "TRAVELLING" else round(rng.uniform(1, 5), 1),
            "1856": seatbelt, "70": "ON" if activity == "OFF" else "OFF", "523": 0,
        }
        sens = {
            "engine_state": "RUNNING", "hyd_pump_press_kpa": 3100 if activity == "IDLE" else 8000,
            "swing_rate_deg_s": 0.0 if activity != "WORKING" else rng.uniform(10, 40),
            "boom_angle_deg": 30.0, "stick_angle_deg": -60.0, "bucket_angle_deg": -15.0,
            "bucket_height_m": 2.0 if activity_hint in ("SWING_LOADED", "DUMPING") else 0.2,
            "boom_tip_height_m": 5.0, "payload_kg": payload_kg,
            "pass_count": ms.pass_count, "load_count": ms.load_count, "idle_hours_total": 0.0,
            "pitch_deg": round(pitch_deg, 2), "roll_deg": round(roll_deg, 2),
            "x_m": round(ms.x_m, 1), "y_m": round(ms.y_m, 1), "heading_deg": round(ms.heading_deg, 1),
            "seat_occupied": seat_occupied, "door_open": door_open, "hyd_lockout": hyd_lockout,
            "joystick_active": activity == "WORKING", "lift_mode": False, "power_mode": "SMART",
            "attachment_id": model["attachment_id"], "coupler_lock": "LOCKED",
            "cab_temp_c": 28.0, "cab_ac_on": True, "articulation_deg": None,
            "activity_hint": activity_hint,
        }
        sim_label = "DTC" if dtc_fire else (active_anomaly if active_anomaly else None)
        raw_msg = raw_v1(ts_iso, machine_id, can, sens, sim_label)

        flat = flat_sample(ts_iso, operator["operator_id"], activity, ms, seatbelt, {
            "engine_load_pct": round(engine_load_pct, 1), "payload_kg": payload_kg,
            "engine_rpm": round(engine_rpm),
            "passthrough": {
                "hyd_lockout": hyd_lockout, "bucket_height_m": sens["bucket_height_m"],
                "seat_occupied": seat_occupied, "door_open": door_open,
                "pitch_deg": sens["pitch_deg"], "roll_deg": sens["roll_deg"],
                "lift_mode": False, "proximity_min_dist_m": proximity_dist,
                "dtc_action_class": dtc_action_class,
            },
        })

        proximity_msg = None
        if proximity_dist is not None:
            proximity_msg = {
                "schema": "proximity.v1", "ts": ts_iso, "machine_id": machine_id,
                "min_dist_m": proximity_dist, "sector": "REAR", "conf": round(rng.uniform(0.5, 0.9), 2),
                "frame_ok": True, "source": "sim",
            }

        dtc_msg = None
        if dtc_fire:
            dtc_msg = {
                "schema": "dtc.v1", "ts": ts_iso, "site_id": SITE_ID, "machine_id": machine_id,
                "spn": dtc_fire["spn"], "fmi": dtc_fire["fmi"], "oc": 1, "cat_code": None,
                "active": True, "freeze_frame": {"hyd_oil_temp_c": ms.hyd_oil_c,
                                                  "engine_load_pct": engine_load_pct, "ambient_c": 30.0},
            }

        yield raw_msg, flat, proximity_msg, dtc_msg


SHIFT_START_HOUR = 6.25   # 06:15
SHIFT_END_HOUR = 17.0     # 17:00
MIN_GAP_MIN, MAX_GAP_MIN = 1, 45  # idle gap between tasks; low end matches HLD's "sub-3-min
                                   # pauses are truck swaps" so idle bucket variety (PAUSE/
                                   # SHORT/MEDIUM/LONG) actually shows up in the data


def _consume_gen(gen, machine_id, anomaly_state, trace_f, rollup, idle, hour_labels,
                  sim_labels_by_hour, hour_state):
    """Shared per-sample bookkeeping for any generator yielding simulate_period()'s or
    simulate_exit()'s (raw_msg, flat, prox_msg, dtc_msg) shape: writes the wrapped trace
    lines, emits env.v1 on schedule, splits idle episodes at hour boundaries, feeds the
    rule-label accumulator, and finalizes hourly windows. Yields finished_hour dicts."""
    last_ts_iso = None
    for raw_msg, flat, prox_msg, dtc_msg in gen:
        trace_f.write(json.dumps(wrap(topic_raw(machine_id), raw_msg)) + "\n")
        last_ts_iso = raw_msg["ts"]

        if prox_msg:
            trace_f.write(json.dumps(wrap(topic_sim_proximity(machine_id), prox_msg)) + "\n")
        if dtc_msg:
            trace_f.write(json.dumps(wrap(topic_dtc(machine_id), dtc_msg)) + "\n")

        gs = anomaly_state["global_s"]
        if gs % 600 == 1:
            w = weather_at(parse_iso(raw_msg["ts"]).astimezone(SITE_TZ))
            env_msg = {
                "schema": "env.v1", "ts": raw_msg["ts"], "site_id": SITE_ID, "source": "SIM",
                "temp_c": w["temp_c"], "rh_pct": w["rh_pct"], "precip_mm_h": 0.0,
                "rain_flag": w["rain_flag"], "wind_kmh": 6, "gust_kmh": 11,
                "visibility_m": 4000, "ground_condition": "WET" if w["is_wet"] else "DRY",
            }
            trace_f.write(json.dumps(wrap(topic_env(), env_msg)) + "\n")

        hour_key = flat["ts"][:13]
        if hour_state["current_hour_key"] is not None and hour_key != hour_state["current_hour_key"]:
            boundary_ts = parse_iso(flat["ts"]).replace(minute=0, second=0, microsecond=0)
            chunk = idle.split_at_boundary(boundary_ts)
            if chunk:
                rollup.add_idle_episode(chunk)
        hour_state["current_hour_key"] = hour_key

        fired = evaluate_sample(flat, MACHINES[machine_id]["model_id"])
        hour_labels.setdefault(hour_key, HourLabelAccumulator())
        hour_labels[hour_key].add_sample(fired)
        if raw_msg["sim_label"]:
            sim_labels_by_hour.setdefault(hour_key, set()).add(raw_msg["sim_label"])

        finished_idle = idle.add_sample(flat)
        if finished_idle:
            rollup.add_idle_episode(finished_idle)
        _finished_minute, finished_hour = rollup.add_sample(flat)
        if finished_hour:
            finished_hour["site_id"] = SITE_ID
            hkey = finished_hour["window_start"][:13]
            lbl = hour_labels.pop(hkey, None)
            finished_hour.update(lbl.finish() if lbl else
                                  {"alert_count": None, "critical_count": None,
                                   "state_class_mode": None, "safety_alert_triggered": None})
            finished_hour["sim_labels"] = sorted(sim_labels_by_hour.pop(hkey, set()))
            yield finished_hour
    _consume_gen.last_ts_iso = last_ts_iso


def _run_period(mode, machine_id, model_id, operator, rng, ms, t0, duration_min, anomaly_state,
                 soil_type, trace_f, rollup, idle, hour_labels, sim_labels_by_hour, hour_state):
    """Runs one simulate_period() call via _consume_gen. Returns the timestamp of the
    last sample written (or t0 if duration<=0), so the caller can chain periods
    back-to-back without gaps or overlaps.

    `hour_state` is a mutable {"current_hour_key": str|None} threaded across periods
    within a shift, used to detect hour rollover so a still-open idle episode can be
    split at the boundary (see idle_tracker.IdleTracker.split_at_boundary)."""
    if duration_min <= 0:
        return t0.isoformat(timespec="milliseconds"), []
    gen = simulate_period(mode, machine_id, model_id, operator, rng, ms, t0, duration_min,
                           anomaly_state, soil_type)
    windows = list(_consume_gen(gen, machine_id, anomaly_state, trace_f, rollup, idle,
                                 hour_labels, sim_labels_by_hour, hour_state))
    last_ts_iso = _consume_gen.last_ts_iso or t0.isoformat(timespec="milliseconds")
    return last_ts_iso, windows


def _run_exit(machine_id, model_id, operator, rng, ms, t0, unsafe, wet, anomaly_state,
              trace_f, rollup, idle, hour_labels, sim_labels_by_hour, hour_state):
    """Runs simulate_exit() via the same bookkeeping as _run_period. Returns
    (last_ts_iso, windows)."""
    gen = simulate_exit(machine_id, model_id, operator, rng, ms, t0, unsafe, wet)
    windows = list(_consume_gen(gen, machine_id, anomaly_state, trace_f, rollup, idle,
                                 hour_labels, sim_labels_by_hour, hour_state))
    last_ts_iso = _consume_gen.last_ts_iso or t0.isoformat(timespec="milliseconds")
    return last_ts_iso, windows
    return last_ts_iso


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=2)
    ap.add_argument("--machines", nargs="+", default=list(MACHINES.keys()))
    ap.add_argument("--extra-operators", type=int, default=2)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--start-date", default="2026-09-01")
    ap.add_argument("--out", default="./data/history")
    args = ap.parse_args()

    rng = random.Random(args.seed)
    out_dir = Path(args.out)
    (out_dir / "traces").mkdir(parents=True, exist_ok=True)
    (out_dir / "anchors").mkdir(parents=True, exist_ok=True)

    operators = make_operator_pool(args.extra_operators, rng)
    op_by_id = {o["operator_id"]: o for o in operators}

    all_windows = []
    all_tasks = []
    start = datetime.strptime(args.start_date, "%Y-%m-%d").date()

    for day_i in range(args.days):
        shift_date = start + timedelta(days=day_i)
        for machine_id in args.machines:
            model_id = MACHINES[machine_id]["model_id"]
            pref_op = MACHINES[machine_id]["operator_pref"]
            operator = op_by_id.get(pref_op, rng.choice(operators))
            ms = MachineState(machine_id=machine_id, model_id=model_id, engine_hours=1500.0 + day_i)

            rollup = RollupAccumulator(machine_id)
            idle = IdleTracker()
            hour_labels: dict[str, HourLabelAccumulator] = {}
            sim_labels_by_hour: dict[str, set] = {}
            anomaly_state = {"active": None, "end_s": -1, "global_s": 0}
            hour_state = {"current_hour_key": None}

            trace_path = out_dir / "traces" / f"{machine_id}_{shift_date.isoformat()}.jsonl"
            cursor = datetime.combine(shift_date, datetime.min.time(), tzinfo=SITE_TZ) + timedelta(hours=SHIFT_START_HOUR)
            shift_end = datetime.combine(shift_date, datetime.min.time(), tzinfo=SITE_TZ) + timedelta(hours=SHIFT_END_HOUR)
            shift_id = f"SH-{shift_date.strftime('%Y%m%d')}-{machine_id}-D"

            with open(trace_path, "w") as trace_f:

                def run(mode, duration_min, soil_type=None):
                    nonlocal cursor
                    last_ts_iso, windows = _run_period(mode, machine_id, model_id, operator, rng, ms,
                                                        cursor, duration_min, anomaly_state, soil_type,
                                                        trace_f, rollup, idle, hour_labels,
                                                        sim_labels_by_hour, hour_state)
                    all_windows.extend(windows)
                    cursor = parse_iso(last_ts_iso) + timedelta(seconds=1)

                valid_types = [t for t, spec in TASK_TYPES.items() if model_id in spec["machines"]]
                # Fill the shift with back-to-back tasks (separated by idle gaps) rather
                # than a fixed count, so idle time stays realistic-sized (15-45 min
                # between tasks) instead of one multi-hour dead zone at the end.
                while (shift_end - cursor).total_seconds() / 60 > 20:
                    task_type_id = rng.choice(valid_types)
                    spec = TASK_TYPES[task_type_id]
                    soil_type = rng.choice(SOIL_TYPES)
                    rate = rng.uniform(*spec["rate"])
                    planned_quantity = round(rng.uniform(200, 450), 0)
                    duration_min = planned_quantity / rate * 60 * PERSONAS[operator["persona"]]["cycle_mult"]
                    duration_min = min(duration_min, (shift_end - cursor).total_seconds() / 60)
                    if duration_min < 5:
                        break

                    task_id = str(uuid7())
                    t_start = cursor
                    run("WORK", duration_min, soil_type)
                    t_end = cursor

                    all_tasks.append({
                        "task_id": task_id, "shift_id": shift_id, "machine_id": machine_id,
                        "operator_id": operator["operator_id"], "task_type_id": task_type_id,
                        "zone_id": "Z-NORTH-CUT", "planned_quantity": planned_quantity,
                        "unit": spec["unit"], "soil_type": soil_type,
                        "material_density_t_m3": SOIL_DENSITY[soil_type],
                        "trucks_assigned": 3 if task_type_id == "TRUCK_LOAD" else None,
                        "truck_capacity_t": 16 if task_type_id == "TRUCK_LOAD" else None,
                        "priority": 2, "scheduled_start": t_start.isoformat(timespec="milliseconds"),
                        "scheduled_end": t_end.isoformat(timespec="milliseconds"),
                        "status": "DONE", "actual_start": t_start.isoformat(timespec="milliseconds"),
                        "actual_end": t_end.isoformat(timespec="milliseconds"),
                        "actual_quantity": planned_quantity * rng.uniform(0.9, 1.05),
                        "duration_min": duration_min,
                    })

                    # idle gap before the next task (truck wait / instructions / break) —
                    # this is what makes idle_ratio, idle_*_count and
                    # seatbelt_unfastened_running_min non-trivial in the training data.
                    gap_min = min(rng.uniform(MIN_GAP_MIN, MAX_GAP_MIN), (shift_end - cursor).total_seconds() / 60)
                    if gap_min > 0.5:
                        run("IDLE", gap_min)

                # idle out most of the remainder of the shift, reserving the last ~30s
                # for the actual dismount sequence (the flagship UNSAFE_EXIT/SAFE_EXIT
                # scenario) rather than ending the trace mid-idle with no exit at all.
                remaining_min = (shift_end - cursor).total_seconds() / 60 - 0.5
                if remaining_min > 0.5:
                    run("IDLE", remaining_min)

                weather_now = weather_at(cursor.astimezone(SITE_TZ))
                is_wet = weather_now["is_wet"]
                unsafe = rng.random() < PERSONAS[operator["persona"]]["p_unsafe_exit"]
                exit_last_ts, exit_windows = _run_exit(
                    machine_id, model_id, operator, rng, ms, cursor, unsafe, is_wet,
                    anomaly_state, trace_f, rollup, idle, hour_labels, sim_labels_by_hour, hour_state,
                )
                all_windows.extend(exit_windows)
                cursor = parse_iso(exit_last_ts) + timedelta(seconds=1)

                # Feed any still-open idle episode into rollup BEFORE closing rollup's
                # own open hour, or it would fall into the same "fed after the hour
                # already closed" trap that split_at_boundary exists to avoid.
                final_idle = idle.close(cursor.isoformat(timespec="milliseconds"))
                if final_idle:
                    rollup.add_idle_episode(final_idle)
                m, h = rollup.close(cursor.isoformat(timespec="milliseconds"))
                if h:
                    h["site_id"] = SITE_ID
                    hkey = h["window_start"][:13]
                    lbl = hour_labels.pop(hkey, None)
                    h.update(lbl.finish() if lbl else
                             {"alert_count": None, "critical_count": None,
                              "state_class_mode": None, "safety_alert_triggered": None})
                    h["sim_labels"] = sorted(sim_labels_by_hour.pop(hkey, set()))
                    all_windows.append(h)

            print(f"wrote {trace_path} ({shift_date}, {machine_id})")

    import pandas as pd
    pd.DataFrame(all_windows).to_parquet(out_dir / "windows.parquet", index=False)
    pd.DataFrame(all_tasks).to_parquet(out_dir / "tasks.parquet", index=False)
    pd.DataFrame(operators).to_parquet(out_dir / "operators.parquet", index=False)
    print(f"\nwindows.parquet: {len(all_windows)} rows")
    print(f"tasks.parquet:   {len(all_tasks)} rows")
    print(f"operators.parquet: {len(operators)} rows")


if __name__ == "__main__":
    main()
