# P1 Training Pipeline — Operator Companion

Generates synthetic training data matching the runtime repo's exact contracts
(`raw.v1`, `task.v1`, `ml_features.md`), trains the two ML models
(`IsolationForest` for anomaly detection, `LightGBM` for ETA prediction), and
transfers the trained weights to the edge box. This repo is **separate from the
runtime repo** — it produces `.joblib` files and a `data/history/` export; it does
not contain the backend, the PWA, or Ollama/Qwen setup (that comes later).

Everything here has been run and verified end-to-end in a sandboxed test
(580,000+ generated messages validated against the real JSON Schemas, all three
models trained and round-tripped through the real `ml_runtime` loader classes,
and the weight-transfer scripts tested with a live HTTP loopback). See
**"Known simplifications and gaps"** at the bottom before treating this as final —
several things are proven-correct-in-mechanism but intentionally simplified in
fidelity, and a couple of things are documented gaps, not bugs.

## Read this first: you probably don't need Jarvis Labs' GPU for this

`IsolationForest` (scikit-learn) runs on CPU only — scikit-learn has no GPU
support at all. `LightGBM`'s default CPU mode is what `train_models.py` uses, and
at this dataset's size (hundreds to low thousands of rows) it trains in seconds
on a laptop CPU; LightGBM's GPU mode only pays off on much larger datasets and
needs a special GPU-enabled build to even use it. **Both training jobs are CPU-
bound, not GPU-bound.** Unless you're also using the same Jarvis Labs instance to
run Qwen (a separate, later task), you can likely do all of Steps 1–3 below for
free in Colab's CPU runtime and skip paying for GPU time entirely. Confirm this
holds once your real dataset is larger — if `train_models.py` starts taking
many minutes, that's the signal to reconsider, not the dataset size alone.

## Pipeline stages

```
simulate.py          -> data/history/{traces/*.jsonl, windows.parquet, tasks.parquet, operators.parquet}
        |                (Layer 1: raw wire-format traces  +  Layer 2: rollup.py-derived hourly windows)
        v
build_features.py    -> data/history/{anomaly_features.parquet, eta_features.parquet}
        |                (Layer 3: exact ml_features.md columns, incl. z-scores vs operator baseline)
        v
train_models.py       -> models/{anomaly_excavator_v1.joblib, anomaly_wheel_loader_v1.joblib,
        |                          eta_v1.joblib, manifest.json}
        v
serve_models.py  (on the training machine)  <---HTTP--->  pull_models.py  (on the edge box)
```

## Step-by-step flow

### 1. Test in Colab first (free, no Jarvis Labs charges yet)

1. Upload this whole folder to Colab (zip it, upload via the Colab file browser,
   then `!unzip training_pipeline.zip`) — or mount Google Drive if you'd rather
   keep it there between sessions.
2. In a Colab cell:
   ```
   !pip install -q -r requirements.txt
   !cd training_pipeline && python3 simulate.py --days 5 --machines EXC001 EXC002 WL001 --extra-operators 2 --seed 7
   !cd training_pipeline && python3 build_features.py
   !cd training_pipeline && python3 train_models.py
   ```
3. Verify the models actually load (this is the check that matters — a model
   that trains but doesn't load through the real interface is useless to the
   backend):
   ```python
   import sys; sys.path.insert(0, "training_pipeline/ml_runtime")
   !pip install -q -e training_pipeline/ml_runtime
   from ml_runtime import EtaModel, AnomalyModel
   eta = EtaModel.load("training_pipeline/models/eta_v1.joblib")
   print(eta.version, eta.predict({...}))  # fill in a realistic feats dict
   ```
4. Once this all runs cleanly, you've proven the pipeline works **before**
   spending any Jarvis Labs money. Scale up `--days`/`--machines`/
   `--extra-operators` in Colab first too — only move to Jarvis Labs once you
   need either (a) a bigger dataset than Colab's disk/RAM comfortably holds, or
   (b) you're training Qwen on the same box later and want one environment.

### 2. Move to Jarvis Labs once you're ready to scale up

1. **Match Python 3.11** — the runtime repo's `backend/pyproject.toml` pins
   `>=3.11,<3.12` and its `requirements.lock` has no `scikit-learn`/`lightgbm`/
   `joblib` yet (you're filling that blank — see `contracts/ml_runtime.md`).
   `ml_runtime/pyproject.toml` in this pipeline is deliberately left as
   `>=3.11` (no upper bound) for convenience testing on newer Pythons — when you
   hand the real package to your backend teammate, tighten it back to
   `>=3.11,<3.12` to match exactly.
2. Same three commands as Colab, just at real scale:
   ```
   python3 simulate.py --days 60 --machines EXC001 EXC002 WL001 --extra-operators 18 --seed 42
   python3 build_features.py
   python3 train_models.py
   ```
   (60 days × ~3-8 machines × ~20 operators was the original HLD's target scale —
   adjust `MACHINES` in `simulate.py` if you add more machine IDs than the 3
   currently defined there.)
3. Start the model registry so the edge box can pull:
   ```
   python3 serve_models.py --models-dir ./models --port 8080
   ```
   Keep this running (or re-run it after every retrain) whenever the edge box
   might poll it. This is a stand-in for the real cloud-api's equivalent
   endpoint (HLD §8.3) — swap it out once that exists, keeping the response
   shape (`GET /models`, `GET /models/{name}/latest`) the same.

### 3. Transfer weights to the edge box

On the edge box, run (this has been tested end-to-end with a live loopback —
first pull downloads everything with SHA-256 verification, second pull with
nothing changed correctly no-ops):
```
python3 pull_models.py --registry-url http://<jarvis-labs-host>:8080 --models-dir ./models
```
- Downloads only what changed (compares `manifest.json` versions).
- Verifies SHA-256 before accepting a file — a partial/corrupt download is
  discarded, never installed.
- Writes to a temp file and atomically renames it into place, so the backend can
  never see a half-written model file.
- Run this on a timer (cron/systemd) on the edge box; it's a fast no-op when
  nothing changed.
- After a real update, the edge backend needs to reload its model objects
  (restart, or implement hot-reload in `backend/edge/ml/adapter.py` per
  `plan.md` §5.6 — that module doesn't exist yet, so for now a restart is fine).

If the edge box has no way to reach the training machine over HTTP (e.g. it's
fully air-gapped even from your Jarvis Labs instance), the alternative is a
direct `scp`/`rsync` push instead:
```
rsync -avz --checksum ./models/ user@edge-box-host:/path/to/models/
```
This skips the sha256-verification-before-swap safety `pull_models.py` gives
you, so prefer the pull-based flow when the edge box can reach the training
machine at all, even intermittently.

## What each file does

| File | Role |
|---|---|
| `common/{ids,timeutil,spn}.py` | Verbatim copies of the runtime repo's `backend/common/*` — kept identical so timestamp/UUID formatting matches exactly. |
| `rollup.py` | Verbatim copy of the backend's (not-yet-pushed) hourly rollup logic — **re-pull this if the real file changes.** |
| `idle_tracker.py` | Reimplementation of the backend's not-yet-built `idle.py`, including a fix for a real gap in `rollup.py`: it silently drops idle episodes that straddle an hour boundary (`split_at_boundary` works around this — see that method's docstring). |
| `rules_subset.py` | A best-effort, non-authoritative subset of `contracts/rules.yaml` (R01, R03, R07, R10-R13, R16-R17) used only to generate `alert_count`/`critical_count`/`state_class_mode` training labels. **Not the real rule engine** — no cooldowns/hysteresis. Replace with a replay through the real engine once it exists. |
| `simulate.py` | The actual data generator — personas, weather, tasks, 6 of 8 injectable anomaly types, and the flagship `UNSAFE_EXIT`/`SAFE_EXIT` dismount sequence. |
| `build_features.py` | Layer 3: turns `windows.parquet`/`tasks.parquet` into the exact `ml_features.md` feature tables, including z-scores vs each operator's trailing baseline. |
| `train_models.py` | Trains and bundles both models to the `ml_runtime`-compatible `.joblib` format. |
| `ml_runtime/` | The actual inference package the backend `pip install`s — same one described in the earlier Claude Code prompt, now with the anomaly model fixed to train/score on z-scores (see its docstrings). |
| `serve_models.py` / `pull_models.py` | Weight transfer, tested end-to-end with a live loopback. |

## Known simplifications and gaps (read before trusting the numbers)

**Data fidelity (won't break the pipeline, will affect model quality):**
- Fuel/temperature dynamics are exponential smoothing toward a state-dependent
  target, not a real thermal/engine model.
- Weather is a single deterministic daily sinusoid, not a real forecast.
- Task soil/quantity sampling is uniform-random within HLD ranges, not tied to a
  real site plan.
- `power_mode` is hardcoded to `"SMART"` everywhere — no variation to learn from.
- `temp_c`/`heat_index_c` in `eta_features.parquet` are currently always `None`
  — needs an env.v1 join at each task's start time (the same join
  `build_features.py` already does for `hyd_oil_temp_over_ambient_c`; extending
  it to the ETA features is a small follow-up, not done here for time).

**Anomaly injection gaps:**
- `BELT_BYPASS` and `OVERHEAT_TREND` are defined in `simulate.py`'s rate tables
  but **not yet actually injected** — only 6 of the 8 injectable `sim_label`
  types are implemented (`HIGH_IDLE_RPM`, `FUEL_INEFFICIENCY`, `TILT_EXCURSION`,
  `PROXIMITY_INTRUSION`, `LONG_IDLE_UNBELTED`, `UNSAFE_EXIT`/`DTC`). Extend
  `simulate_period()` the same way the existing ones work if you need these two
  represented in training data.

**Anchor traces — not built:**
- `data/history/anchors/EXC001_2025-05-0{1,2}.jsonl` (the traces that must
  reproduce the four organizer sample rows from HLD §6.13 exactly) are **not
  implemented in this pipeline.** This needs a dedicated, hand-tuned generator
  (not the random `simulate.py`) precisely engineered to hit those four specific
  numbers. It's a correctness *test* artifact, not training data — the models
  train fine without it — but it's still owed as a `history.md` deliverable.

**LightGBM monotone constraint dropped:**
- `contracts/ml_features.md`/HLD §7.2 ask for a monotone constraint (quantity up
  → duration up). LightGBM's C API rejects `monotone_constraints` together with
  the `quantile` objective (a real error hit while building this: *"Cannot use
  `monotone_constraints` in quantile objective, please disable it"*) — so it's
  left off. If this constraint matters enough to keep, the alternative is
  training with `objective="regression"` (L2) and calibrating p50/p90 some other
  way (e.g. quantile of residuals) — a bigger change than fit here.

**Rule evaluation is a subset, not the real engine:**
- See `rules_subset.py`'s own docstring. `alert_count`/`critical_count`/
  `state_class_mode` in the generated data are "directionally right, not
  authoritative" until replayed through the real rule engine once backend
  builds it.

**Environment applies at once-per-site granularity in the training loop:**
- `env.v1` is embedded per-machine trace file (redundant across machines on the
  same site/day) so each file stays self-contained for replay — a deliberate
  choice, documented in `simulate.py`'s module docstring, not a bug.
