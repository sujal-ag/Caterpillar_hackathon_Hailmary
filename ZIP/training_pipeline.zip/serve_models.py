"""Runs ON the Jarvis Labs GPU instance (or wherever training happens) after
train_models.py finishes. Exposes the model files over HTTP so the edge box can
PULL them whenever it has connectivity — matching this project's own architecture
(HLD §8.3: `GET /models/{name}/latest -> versioned file + sha256`) rather than
requiring inbound SSH/rsync access to the edge box, which is often impractical
once the edge box is behind a site LAN / NAT with no public IP.

This is intentionally NOT the real backend cloud-api (backend/cloud/) — it is a
small, standalone stand-in P1 can run next to the training job so pull_models.py
has something to poll. Swap it for the real cloud-api's equivalent endpoint once
that exists, keeping the same response shape so pull_models.py doesn't change.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from fastapi import FastAPI, HTTPException
from fastapi.responses import FileResponse

app = FastAPI(title="P1 model registry (training-side stand-in)")
MODELS_DIR = Path("./models")


def _manifest() -> dict:
    manifest_path = MODELS_DIR / "manifest.json"
    if not manifest_path.exists():
        raise HTTPException(404, "No manifest.json — run train_models.py first")
    return json.loads(manifest_path.read_text())


@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/models")
def list_models():
    """All models currently available, with version + sha256 — same shape as
    a single-model /latest response, just for every file at once."""
    return _manifest()["models"]


@app.get("/models/{name}/latest")
def latest(name: str):
    """HLD §8.3 contract: versioned model file + sha256. `name` is the filename
    (e.g. eta_v1.joblib, anomaly_excavator_v1.joblib) — matching manifest.json's keys."""
    manifest = _manifest()
    if name not in manifest["models"]:
        raise HTTPException(404, f"No such model: {name}. Available: {list(manifest['models'])}")
    info = manifest["models"][name]
    file_path = MODELS_DIR / name
    if not file_path.exists():
        raise HTTPException(410, f"{name} is in the manifest but the file is missing on disk")
    return FileResponse(
        file_path, media_type="application/octet-stream", filename=name,
        headers={"X-Model-Version": info["version"], "X-Model-Sha256": info["sha256"]},
    )


def main():
    import uvicorn
    ap = argparse.ArgumentParser()
    ap.add_argument("--models-dir", default="./models")
    ap.add_argument("--host", default="0.0.0.0")
    ap.add_argument("--port", type=int, default=8080)
    args = ap.parse_args()
    global MODELS_DIR
    MODELS_DIR = Path(args.models_dir)
    uvicorn.run(app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
