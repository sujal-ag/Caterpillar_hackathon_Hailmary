"""Trains the two models and saves them as .joblib bundles in the exact internal
format ml_runtime/{eta,anomaly}.py expect (see those files' docstrings).

Run after build_features.py. Designed to run identically on a laptop, in Colab, or
on a Jarvis Labs GPU instance — neither IsolationForest nor LightGBM (CPU mode, the
default) benefit from a GPU at this dataset size; see the README for why paying for
GPU time is likely unnecessary for these two models specifically.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import statistics
from datetime import datetime, timezone
from pathlib import Path

import joblib
import lightgbm as lgb
import numpy as np
import pandas as pd
from sklearn.ensemble import IsolationForest

from simulate import MACHINES

ANOMALY_NUMERIC_METRICS = [
    "idle_ratio", "fuel_per_productive_h", "fuel_per_load", "loads_per_productive_h",
    "passes_per_h", "seatbelt_unfastened_running_min", "long_idle_count",
    "elevated_rpm_idle_min", "mean_engine_load_pct", "hyd_oil_temp_over_ambient_c",
    "alert_count",
]
ANOMALY_CATEGORICAL = ["task_type", "power_mode"]

ETA_NUMERIC = [
    "planned_quantity", "fill_factor", "material_density_t_m3", "haul_distance_m",
    "truck_capacity_total_t", "attachment_capacity_m3", "operator_rate_median",
    "experience_years", "readiness_score", "rain_mm_h", "temp_c", "heat_index_c",
    "start_hour", "hours_into_shift", "day_of_week",
]
ETA_CATEGORICAL = ["task_type", "unit", "soil_type", "machine_model", "power_mode", "operator_rate_source"]


def _build_categorical_maps(df: pd.DataFrame, columns: list[str]) -> dict:
    maps = {}
    for col in columns:
        values = sorted(v for v in df[col].dropna().unique())
        maps[col] = {v: i for i, v in enumerate(values)}
        maps[col]["__unknown__"] = -1
    return maps


def _encode(df: pd.DataFrame, numeric: list[str], categorical: list[str], cat_maps: dict) -> np.ndarray:
    cols = []
    for col in numeric:
        cols.append(pd.to_numeric(df[col], errors="coerce").fillna(0.0).to_numpy())
    for col in categorical:
        m = cat_maps[col]
        cols.append(df[col].map(lambda v: m.get(v, m["__unknown__"])).to_numpy())
    return np.column_stack(cols)


def train_anomaly(history_dir: Path, models_dir: Path) -> list[Path]:
    feats = pd.read_parquet(history_dir / "anomaly_features.parquet")
    family_by_machine = {m: MACHINES[m]["model_id"] for m in MACHINES}
    # MACHINES maps machine_id -> model_id (CAT-320/CAT-950GC); the model is trained
    # per FAMILY (EXCAVATOR/WHEEL_LOADER), so map model_id -> family here.
    from simulate import MACHINE_MODELS
    family_of_model = {m: MACHINE_MODELS[m]["family"] for m in MACHINE_MODELS}
    feats["family"] = feats["machine_id"].map(family_by_machine).map(family_of_model)

    z_cols = [f"z_{m}" for m in ANOMALY_NUMERIC_METRICS]
    feature_names = z_cols + ANOMALY_CATEGORICAL
    written = []

    for family, group in feats.groupby("family"):
        if len(group) < 10:
            print(f"[anomaly:{family}] only {len(group)} rows — skipping, need more data "
                  f"(increase --days/--machines in simulate.py)")
            continue

        cat_maps = _build_categorical_maps(group, ANOMALY_CATEGORICAL)
        z_matrix = group[z_cols].apply(pd.to_numeric, errors="coerce").fillna(0.0).to_numpy()
        cat_matrix = np.column_stack([
            group[col].map(lambda v: cat_maps[col].get(v, cat_maps[col]["__unknown__"])).to_numpy()
            for col in ANOMALY_CATEGORICAL
        ])
        X = np.column_stack([z_matrix, cat_matrix])

        model = IsolationForest(n_estimators=200, contamination=0.03, random_state=0)
        model.fit(X)

        raw_scores = -model.score_samples(X)
        threshold_top3pct = float(np.percentile(raw_scores, 97))

        fuel_per_load_median = float(
            pd.to_numeric(group["fuel_per_load"], errors="coerce").dropna().median() or 0.0
        )

        bundle = {
            "version": f"anomaly-iforest-{family.lower()}-{datetime.now(timezone.utc):%Y.%m.%d}",
            "family": family,
            "threshold_top3pct": threshold_top3pct,
            "feature_names": feature_names,
            "categorical_maps": cat_maps,
            "fuel_per_load_default_median": fuel_per_load_median,
            "model": model,
        }
        out_path = models_dir / f"anomaly_{family.lower()}_v1.joblib"
        joblib.dump(bundle, out_path)
        written.append(out_path)
        print(f"[anomaly:{family}] trained on {len(group)} rows, threshold_top3pct={threshold_top3pct:.4f} "
              f"-> {out_path}")

    return written


def train_eta(history_dir: Path, models_dir: Path) -> list[Path]:
    feats = pd.read_parquet(history_dir / "eta_features.parquet")
    before = len(feats)
    feats = feats[feats["operator_rate_median"].notna()].reset_index(drop=True)
    dropped = before - len(feats)
    if dropped:
        print(f"[eta] dropped {dropped}/{before} rows with no operator/cohort/task-type rate "
              f"available yet (true cold start) — not usable as training examples")

    if len(feats) < 10:
        print(f"[eta] only {len(feats)} usable rows — skipping, need more data")
        return []

    cat_maps = _build_categorical_maps(feats, ETA_CATEGORICAL)
    X = _encode(feats, ETA_NUMERIC, ETA_CATEGORICAL, cat_maps)
    y = np.log1p(pd.to_numeric(feats["duration_min"], errors="coerce").to_numpy())

    feature_names = ETA_NUMERIC + ETA_CATEGORICAL
    ds = lgb.Dataset(X, label=y, feature_name=feature_names,
                      categorical_feature=[feature_names.index(c) for c in ETA_CATEGORICAL],
                      free_raw_data=False)  # reused for two lgb.train() calls below (p50 and p90)

    # NOTE: contracts/ml_features.md / HLD §7.2 ask for a monotone constraint (quantity
    # up -> duration up). LightGBM's C API rejects monotone_constraints together with
    # the quantile objective ("Cannot use `monotone_constraints` in quantile objective,
    # please disable it" — a real error hit while building this, not a guess), so it's
    # left off both quantile models. If this constraint matters enough to keep, the
    # alternative is training with objective="regression" (L2) and calibrating p50/p90
    # some other way (e.g. quantile of residuals), which is a bigger change than fits
    # here — flagging as an open decision rather than silently dropping the ask.
    params_common = {"verbosity": -1, "min_data_in_leaf": max(5, len(feats) // 20)}
    model_p50 = lgb.train({**params_common, "objective": "quantile", "alpha": 0.5}, ds, num_boost_round=100)
    model_p90 = lgb.train({**params_common, "objective": "quantile", "alpha": 0.9}, ds, num_boost_round=100)

    # quick in-sample sanity numbers (NOT a held-out eval — see README for the real
    # time-based-split evaluation contracts/ml_features.md's HLD reference expects)
    pred_p50 = np.expm1(model_p50.predict(X))
    actual = feats["duration_min"].to_numpy()
    mae = float(np.mean(np.abs(pred_p50 - actual)))
    print(f"[eta] trained on {len(feats)} rows, in-sample MAE={mae:.1f} min "
          f"(in-sample only — evaluate on a held-out time split before trusting this)")

    bundle = {
        "version": f"eta-lgbm-{datetime.now(timezone.utc):%Y.%m.%d}",
        "feature_names": feature_names,
        "categorical_maps": cat_maps,
        "model_p50": model_p50,
        "model_p90": model_p90,
    }
    out_path = models_dir / "eta_v1.joblib"
    joblib.dump(bundle, out_path)
    print(f"[eta] -> {out_path}")
    return [out_path]


def write_manifest(models_dir: Path, written: list[Path]) -> Path:
    """Version + sha256 manifest — this is what the weight-transfer scripts (see
    push_models.py / serve_models.py / pull_models.py) use to detect a new version
    and verify integrity after transfer, mirroring the HLD §8.3
    `GET /models/{name}/latest -> versioned file + sha256` contract."""
    manifest = {"generated_at": datetime.now(timezone.utc).isoformat(), "models": {}}
    for path in written:
        sha256 = hashlib.sha256(path.read_bytes()).hexdigest()
        bundle_version = joblib.load(path).get("version", "unknown")
        manifest["models"][path.name] = {
            "version": bundle_version, "sha256": sha256, "size_bytes": path.stat().st_size,
        }
    manifest_path = models_dir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, indent=2))
    print(f"\nmanifest -> {manifest_path}")
    return manifest_path


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--history-dir", default="./data/history")
    ap.add_argument("--models-dir", default="./models")
    args = ap.parse_args()
    history_dir, models_dir = Path(args.history_dir), Path(args.models_dir)
    models_dir.mkdir(parents=True, exist_ok=True)

    written = []
    written += train_anomaly(history_dir, models_dir)
    written += train_eta(history_dir, models_dir)
    if written:
        write_manifest(models_dir, written)
    else:
        print("Nothing trained — check that build_features.py ran and produced enough rows.")


if __name__ == "__main__":
    main()
